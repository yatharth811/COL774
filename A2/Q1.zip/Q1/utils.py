import pandas as pd
def read_data(path: str):
    reader = pd.read_csv(path)
    reader['CoronaTweet'] = reader['CoronaTweet'].str.lower()
    return reader
